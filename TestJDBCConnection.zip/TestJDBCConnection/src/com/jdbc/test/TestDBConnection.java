package com.jdbc.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class TestDBConnection {
	
    public static String drivername;
	
	public static String url;
	
	public static String username;
	
	public static String pwd;
	
	
	@BeforeClass
	public static void setUpBeforeClass() {
		drivername ="com.mysql.jdbc.Driver";
		url = "jdbc:mysql://localhost:3306/mydb";
		username= "root";
		pwd ="Alpha@001";
	}
	

	@Test
	public void DBConnectionTest(){
		
		DBConnection DBCon= new DBConnection();
		
		assertEquals("Success",DBCon.connect(drivername, url, username, pwd));
	}

}
