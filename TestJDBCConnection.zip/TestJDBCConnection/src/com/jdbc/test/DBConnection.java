package com.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection  {

	
	
	public String connect(String drivername,String url,String username,String pwd) {
		
		Connection conn = null;
        try {
            Class.forName(drivername);
            conn = DriverManager.getConnection(url, username, pwd);
            if (conn != null) {
            	return "Success";
            }
		}
        catch (ClassNotFoundException ex) {
            System.out.println("Could not find database driver class");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

                }
        }
		return "failure";
        
	}
}
