package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestAcctName {

	@Test
	public void testAcctName() {
		AccountDetails acctdetails = new AccountDetails();
		
		String acctName= "Saving Account";
		
		assertEquals(acctName, acctdetails.AcctName(acctName));
		
	}

}