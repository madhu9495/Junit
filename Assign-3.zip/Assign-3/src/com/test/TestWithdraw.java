package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public class TestWithdraw {

	@Test
	public void testWithdraw() {
		AccountDetails acctdetails = new AccountDetails();
		
		assertEquals("Amount Withdrawn",acctdetails.Withdraw());
		
	}

}
