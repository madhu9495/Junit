package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestAcctBalance {

	@Test
	public void testAcctBalance() {
		AccountDetails acctdetails = new AccountDetails();
		
		float AcctBalance= (float) 1500.80;
		
		assertEquals(AcctBalance, acctdetails.AcctBalance(AcctBalance), 0.0001);
		
	}
}
