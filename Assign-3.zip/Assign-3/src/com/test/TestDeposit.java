package com.test;


import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestDeposit {

	@Test
	public void testDeposit() {
		AccountDetails acctdetails = new AccountDetails();
		
		assertEquals("Amount Deposited",acctdetails.Deposit());
		
	}

}
