package com.test;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({TestAcctNo.class, TestAcctName.class, TestAcctBalance.class, TestDeposit.class, TestWithdraw.class})
public class TestSuite {


}
