package com.test;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestAcctNo {

	@Test
	public void testAcctNo() {
		AccountDetails acctdetails = new AccountDetails();
		
		int acctNo= 55568585;
		
		assertEquals(acctNo, acctdetails.AcctNo(acctNo));
		
	}

}
