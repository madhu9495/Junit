package com.test;

public class AccountDetails {
	
	public int acctNo;
	
	public String acctName;
	
	public float acctBalance;


	public int  AcctNo(int acctNo) {
		this.acctNo = acctNo;
		
		return acctNo;
	}


	public String AcctName(String acctName) {
		this.acctName = acctName;
		
		return acctName;
	}


	public float AcctBalance(float acctBalance) {
		this.acctBalance = acctBalance;
		
		return acctBalance;
	}
	
	public String Deposit() {
		
		return "Amount Deposited";
		
	}
	
	public String Withdraw() {
		
		return "Amount Withdrawn";
		
	}

}
