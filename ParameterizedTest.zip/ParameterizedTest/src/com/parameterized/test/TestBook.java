package com.parameterized.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)
public class TestBook {
	
	private int price;
	private double discount;
	private double expectedResult;
	private Book book;
	
	public TestBook(int price,double discount,double expectedResult) {
		super();
		this.price = price;
		this.discount = discount;
		this.expectedResult = expectedResult;
	}
	
	@Before
	public void initialize() {
		book = new Book();
	}
	
	@Parameterized.Parameters
	public static Collection input() {
		return Arrays.asList(new Object[][] {{1000,20.5,795},{1100,20.5,874.5},{1660,25.5,1236.7}});
	}

	@Test
	public void testDiscountprice() {
		System.out.println("Discount Price is: " +expectedResult);
		assertEquals(expectedResult, book.discountedPrice(price, discount),0.0001);
	}

}
