package com.parameterized.test;

public class Book {
	
	public double discountedPrice(int price,double discount) {
		
		double discountamount;
		discountamount = (discount/100)*price;
		
		return (double)price - discountamount;
		
	}
}
